# Default Config

This directory contains the default overworld configuration for Terra.